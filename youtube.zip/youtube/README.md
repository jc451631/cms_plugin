Youtube Subs plugin
A widget plugin to display youtube channel with subscribe option and subscriber count.

### Version
1.0.0